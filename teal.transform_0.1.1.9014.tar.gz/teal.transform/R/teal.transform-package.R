#' teal.transform: Functions for extracting and merging data in the `teal` framework
#' @keywords internal
"_PACKAGE"

#' @import shiny
#' @importFrom magrittr %>%
#' @importFrom formatters var_relabel var_labels
#' @importFrom lifecycle badge
NULL
