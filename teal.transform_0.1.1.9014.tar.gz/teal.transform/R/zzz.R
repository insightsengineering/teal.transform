.onLoad <- function(libname, pkgname) { # nolint
  teal.logger::register_logger("teal.transform")
  invisible()
}
