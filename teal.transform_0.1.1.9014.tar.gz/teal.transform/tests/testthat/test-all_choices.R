testthat::test_that("all_choices constructor does not throw", {
  testthat::expect_error(all_choices(), NA)
})
